#!/bin/bash
# this for Yab mem monitor

mem_total() {
	free -m | awk 'NR==2 {print $2}'
}

# 服务器已使用内存,program 使用的内存 + buffers + cached
mem_sysuse() {
	free -m | awk 'NR==2 {print $3+$6}'
}

# 用户实际使用
mem_user() {
	free -m | awk 'NR==2 {print $3}'
}

# 系统剩余内存
mem_sysremainmem() {
	free -m | awk 'NR==2 {print $4}'
}

# 剩余内存百分比
mem_syspercent() {
	free -m | awk 'NR==2 {print $4/$2 * 100}'
}

# 使用内存百分比
mem_usepercent() {
	free -m | awk 'NR==2 {print ($3+$6)/$2 * 100}'
}

$1

