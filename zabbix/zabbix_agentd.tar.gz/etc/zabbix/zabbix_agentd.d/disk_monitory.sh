#!/bin/bash
# this script is for disk monitor

# 磁盘总容量
disk_total() {
    df | awk 'NR==2 {print $2*1024}'
}

# 磁盘使用容量
disk_used() {
    df | awk 'NR==2 {print $3*1024}'
}

# 磁盘剩余容量
disk_avail() {
    df | awk 'NR==2 {print $4*1024}'
}

# 磁盘剩余百分比
disk_respercent() {
    df | awk 'NR==2 {print $4/$2 * 100}'
}

# 磁盘使用百分比
disk_usepercent() {
    df | awk 'NR==2 {print $3/$2 * 100}'
}

$1
