#!/bin/bash
# this script is for monitor app

port=$1
state_mon() {
    # netstat -natup | grep $1
    netstat -natup | grep "$port" | awk '{print $4}'|awk -F: '{print $2}'| grep "$port" | tail -1 
}

state_estab() {
    netstat -natup | grep ":$port" | grep ESTABLISHED | wc -l 
}

$2
