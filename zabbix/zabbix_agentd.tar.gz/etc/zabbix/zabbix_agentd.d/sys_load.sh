#!/bin/bash
# this script for systemload

# 系统进程总数
sysproc_total() {
    top -bn1 | awk 'NR==2 {print $2}'
}

# 系统正在运行的进程数量
sysproc_running() {
    top -bn1 | awk 'NR==2 {print $4}'
}

# 系统过去1, 5, 15分钟的平均负载

sysload_1min() {
    uptime |awk -F '[, ]+' '{print $9}'
    # uptime | awk -F '[ ,]+' '{print $8}'
}

sysload_5min() {
    uptime |awk -F '[, ]+' '{print $10}'
    # uptime | awk -F '[ ,]+' '{print $9}'
}

sysload_15min() {
    uptime |awk -F '[, ]+' '{print $11}'
    # uptime | awk -F '[ ,]+' '{print $10}'
}

syspro_zombie() {
    top -bn1| awk 'NR==2 {print $10}'
}

$1
