#/bin/bash
# this script is for system information

# cpu核数
sys_cpu() {
    grep "physical id" /proc/cpuinfo | wc -l
}

# 获取设备主机名
sys_hostname() {
    hostname
}

# 获取zabbix_agent idname
sys_zabbixname() {  
    grep Hostname /etc/zabbix/zabbix_agentd.conf | awk -F'=' '{print $2}'
}

# 获取系统内核版本信息
sys_uname() {
    uname -r
}

# 获取主机ip地址
sys_ip(){
    ifconfig | grep broadcast | awk '{print $2}'
}

$1
