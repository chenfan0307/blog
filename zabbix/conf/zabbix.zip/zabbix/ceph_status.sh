#/bin/shell
# ceph status

container_name=$1

health_status() {
  result=`sudo docker exec $1 ceph -s | grep health`
  echo $result
}

# 数值是否一致
total_numbers() {
  result = `sudo docker exec $1 ceph osd stat | awk -F '[ :]+' '{if ($2=$4=$6) print "ok"; else print "flase"}'`
    # osd: 18 osds: 18 up, 18 in
  echo $result
}

#  number osds
osd_numbers() {
  result=`sudo docker exec $1 ceph osd stat | awk -F '[ :]+' '{print $2}'`
  echo $result
}

# number up
up_numbers() {
  result=`sudo docker exec $1 ceph osd stat | awk -F '[ :]+' '{print $4}'`
  echo $result
}

# number in 
in_numbers() {
  result=`sudo docker exec $1 ceph osd stat | awk -F '[ :]+' '{print $6}'`
  echo $result
}

$2
