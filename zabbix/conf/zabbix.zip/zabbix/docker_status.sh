#!/bin/bash
#

container_name=$1
`sudo docker ps -a | grep -v 'CREATED' | awk -F '[ "/]+' '{print $8,$NF}'>/tmp/docker_status.log`
# result=`grep $1 /tmp/docker_status.log | awk '{print $1}'`
result=`grep $container_name /tmp/docker_status.log | awk '{print $1}'`
echo $result
