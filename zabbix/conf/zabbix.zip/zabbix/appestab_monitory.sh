
#!/bin/bash
# this script is for monitor app
port=
# 判断系统是否存在某端口
state_mon() {
# netstat -natup | grep 
netstat -natup | grep  | awk '{print }'|awk -F: '{print }'| grep  | tail
-1
}
# 过滤统计系统建立连接状态数
state_estab() {
netstat -natup | grep : | grep ESTABLISHED | wc -l
}

