#!/bin/bash
#system process discovery script

container_name=`sudo docker ps |grep -v 'CONTAINER ID'|awk {'print $NF'}`


length=`echo "${container_name}" | wc -l`
count=0
echo '{'
echo -e '\t"data":['
echo "$container_name" | while read line
do
    echo -en '\t\t{"{#CONTAINERNAME}":"'$line'"}'
    count=$(( $count + 1 ))
    if [ $count -lt $length ];then
        echo ','
    fi
done
echo -e '\n\t]'
echo '}'
