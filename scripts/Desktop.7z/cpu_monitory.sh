#!/bin/bash
# this is for monitor cpu 

# CPU处于空闲状态的百分比，空闲时间持续为0，系统时间是用户时间的2倍，cpu资源紧张
function cpu_idel() {
	# top -b -n 1 | awk 'NR==3 {print $8}' 
	top -bn1 | awk -F'[ ,]+' 'NR==3 {print $8}'

# 系统上下文切换的消耗，若此值过高，说明服务器开启太多进程或线程
function cpu_sys() {
	top -bn1 | awk -F'[ ,]+' 'NR==3 {print $4}'
}

# 用户消耗的cpu时间百分比，如果此值长期超过50%，请优化程序算法或者进行加速
function cpu_user() {
	top -bn1 | awk -F'[ ,]+' 'NR==3 {print $2}'
}

# io等待消耗cpu时间的百分比，值高说明磁盘大量的读写，也可能是磁盘性能瓶颈
function cpu_iowait() {
	top -bn1 | awk -F'[ ,]+' 'NR==3 {print $10}'
}

# 其他占用cpu百分比(Nice+SoftIrq+Irq+Stolen)
function cpu_other() {
	top -b -n 1 | awk 'NR==3 {print $6+$12+$14+$16}'
}

# 当前消耗的cpu百分比
function cpu_now() {
	top -b -n 1 | awk 'NR==3 {print $2+$4+$6+$10+$12+$16}'
}

$1
